import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, Alert, Image, StyleSheet } from 'react-native';

export default function SubscribeScreen() {
  const [email, setEmail] = useState('');

  const handleSubscribe = () => {
    Alert.alert('Subscribed!', `Thank you for subscribing with ${email}`);
  };

  return (
    <View style={styles.container}>
      <Image source={require('../assets/little-lemon-logo.png')} style={styles.logo} />
      <Text style={styles.title}>Subscribe to our Newsletter</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter your email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
      />
      <Pressable
        style={[styles.button, !email && styles.buttonDisabled]}
        onPress={handleSubscribe}
        disabled={!email}
      >
        <Text style={styles.buttonText}>Subscribe</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 16 },
  logo: { width: 100, height: 100, marginBottom: 20, resizeMode: 'contain' },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 10 },
  input: { borderWidth: 1, borderColor: '#ccc', borderRadius: 5, padding: 10, width: '100%', marginBottom: 20 },
  button: { backgroundColor: '#f4ce14', padding: 10, borderRadius: 8 },
  buttonDisabled: { backgroundColor: '#ccc' },
  buttonText: { color: 'black', fontSize: 16 },
});
