//
//  MenuList.swift
//  Restaurant
//
//  Created by sokolli on 2/23/25.
//

import Foundation

struct MenuList: Decodable {
    let menu: [MenuItem]
}
